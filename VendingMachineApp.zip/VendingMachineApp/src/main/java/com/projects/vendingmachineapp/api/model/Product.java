package com.projects.vendingmachineapp.api.model;

public class Product {
    private String name;
    private double price;
    private int inventory;

    public Product(){
    }
    public Product(String name, double price, int inventory) {
        super();
        this.name = name;
        this.price = price;
        this.inventory = inventory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getInventory() {
        return inventory;
    }

    public void setInventory(int inventory) {
        this.inventory = inventory;
    }
}
