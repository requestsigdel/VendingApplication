package com.projects.vendingmachineapp.api.controller;

import com.projects.vendingmachineapp.api.model.Product;
import com.projects.vendingmachineapp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    public ProductService getProductService() {
        return productService;
    }

    public void setProductService(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return getProductService().getAllProducts();
    }

    @RequestMapping(method= RequestMethod.PUT, value="/products/{item}")
    public void updateProduct(@RequestBody Product product, @PathVariable String item){
        // get the type of the product and deduct count and return to the user
        getProductService().updateProduct(item, product);
    }
}
