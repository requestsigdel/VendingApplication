package com.projects.vendingmachineapp.service;

import com.projects.vendingmachineapp.api.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class ProductService {
    private List<Product> allProducts = new ArrayList<>(Arrays.asList(
            new Product("Soda", 0.95, 10),
            new Product("Candy Bar", 0.60, 10),
            new Product("Candy Bar", 0.99, 10)
    ));

    public List<Product> getAllProducts(){
        return allProducts;
    }

    public void updateProduct(String item, Product product){
        System.out.println("Goes here");
        for (int i = 0; i < allProducts.size(); i++){
            Product pr = allProducts.get(i);
            if (pr.getName().equals(item)){
                allProducts.set(i, product);
            }
        }
    }
}
